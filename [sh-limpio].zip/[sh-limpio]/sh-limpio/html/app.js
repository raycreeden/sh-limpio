$(document).ready(function() {
    // Ocultar interfaz al inicio
    $('.main').hide();
    
    window.addEventListener('message', function(event) {
        let data = event.data;
        if (data.action === 'open') {
            $('.main').show();
            $('.playerName').text(data.playerName);
            $('.levelText').text('Nvl ' + data.level);
            $('.xp').text(data.xp + ' XP');
            $('.job[data-job="calle"] .price').text('$' + data.sprice);
            $('.job[data-job="calle"] .max').text(data.streetStep + ' pts');
            $('.job[data-job="jardin"] .price').text('$' + data.gprice);
            $('.job[data-job="jardin"] .max').text(data.gardenStep + ' pts');
            $('.job[data-job="ventana"] .price').text('$' + data.wprice);
             $('.job[data-job="ventana"] .max').text(data.windowStep + ' pts');
        } else if (data.action === 'levelUp') {
            // Mostrar animacion de subida de nivel
            console.log('Subio de nivel!');
        }
    });

    $('.start').on('click', function() {
        let job = $(this).closest('.job').data('job');
        $.post('https://sh-limpio/selectJob', JSON.stringify({ selected: job }));
        $('.main').fadeOut(300);
        $.post('https://sh-limpio/close', JSON.stringify({}));
    });

    $(document).on('keyup', function(e) {
        if (e.key === 'Escape' || e.key === 'Backspace') {
            $('.main').fadeOut(300);
            $.post('https://sh-limpio/close', JSON.stringify({}));
        }
    });
});