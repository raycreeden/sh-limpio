local QBCore = exports['qb-core']:GetCoreObject()

QBCore.Functions.CreateCallback('sh-limpio:obtenerDatos', function(source, cb)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    
    if not player then return cb(nil) end
    
    local identificador = player.PlayerData.citizenid
    local resultado = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_cleaner WHERE identifier = ?', { identificador })
    
    if resultado[1] then
        cb({
            nivel = resultado[1].level,
            xp = resultado[1].xp,
            nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        })
    else
        MySQL.Async.execute('INSERT INTO sh_cleaner (identifier, level, xp) VALUES (?, ?, ?)', {
            identificador, 1, 0
        })
        cb({
            nivel = 1,
            xp = 0,
            nombre = player.PlayerData.charinfo.firstname .. " " .. player.PlayerData.charinfo.lastname
        })
    end
end)

QBCore.Functions.CreateCallback('sh-limpio:agregarXpDinero', function(source, cb, datos)
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    
    if not player then return cb(false) end
    
    local identificador = player.PlayerData.citizenid
    local resultado = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_cleaner WHERE identifier = ?', { identificador })
    
    if resultado and resultado[1] then
        local xpActual = resultado[1].xp
        local nuevaXp = xpActual + datos.xp
        local nivelActual = resultado[1].level
        local xpRequerida = Config.Trabajos.ajustes.niveles[nivelActual].siguienteNivel
        
        -- CORREGIDO: Agregar dinero al jugador
        player.Functions.AddMoney('bank', datos.money, "Trabajo de limpieza")
        
        if nuevaXp >= xpRequerida and nivelActual < 10 then
            local nuevoNivel = nivelActual + 1
            MySQL.Sync.execute('UPDATE sh_cleaner SET xp = ?, level = ? WHERE identifier = ?', { nuevaXp, nuevoNivel, identificador })
            cb('subioNivel')
        else
            MySQL.Sync.execute('UPDATE sh_cleaner SET xp = ? WHERE identifier = ?', { nuevaXp, identificador })
            cb(true)
        end
    else
        cb(false)
    end
end)