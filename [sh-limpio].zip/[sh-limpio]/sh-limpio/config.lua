Config = {}

-- Configuracion de la empresa
Config.Empresa = {
    ped = 's_m_m_lifeinvad_01',
    ubicacion = vector4(-1269.11, -1153.86, 5.79, 113.9),
    nombre = 'Servicios de Limpieza SH',
    tamanoBlip = 0.5,
    colorBlip = 3,
    spriteBlip = 77,
    vehiculoTrabajo = 'pony',
    ubicacionVehiculo = vector4(-1273.15, -1158.42, 5.91, 113.52),
    devolverVehiculo = vector3(-1283.38, -1155.57, 5.67)
}

-- Configuracion general
Config.MultaVehiculo = 300
Config.UsarTarget = false
Config.ComandoCancelar = 'cancelartrabajo'

-- Configuracion de trabajos
Config.Trabajos = {
    ajustes = {
        ["calle"] = {
            { nivel = 1, precio = 10, xp = 10 },
            { nivel = 2, precio = 20, xp = 10 },
            { nivel = 3, precio = 25, xp = 10 },
            { nivel = 4, precio = 30, xp = 10 },
            { nivel = 5, precio = 40, xp = 9 },
            { nivel = 6, precio = 45, xp = 8 },
            { nivel = 7, precio = 50, xp = 7 },
            { nivel = 8, precio = 55, xp = 6 },
            { nivel = 9, precio = 65, xp = 2 },
            { nivel = 10, precio = 80, xp = 1 }
        },
        ["jardin"] = {
            { nivel = 1, precio = 20, xp = 10 },
            { nivel = 2, precio = 30, xp = 10 },
            { nivel = 3, precio = 35, xp = 10 },
            { nivel = 4, precio = 50, xp = 10 },
            { nivel = 5, precio = 55, xp = 9 },
            { nivel = 6, precio = 65, xp = 8 },
            { nivel = 7, precio = 70, xp = 7 },
            { nivel = 8, precio = 85, xp = 6 },
            { nivel = 9, precio = 95, xp = 2 },
            { nivel = 10, precio = 100, xp = 1 }
        },
        ["ventana"] = {
            { nivel = 1, precio = 5, xp = 10 },
            { nivel = 2, precio = 10, xp = 10 },
            { nivel = 3, precio = 15, xp = 10 },
            { nivel = 4, precio = 20, xp = 10 },
            { nivel = 5, precio = 25, xp = 9 },
            { nivel = 6, precio = 30, xp = 8 },
            { nivel = 7, precio = 35, xp = 7 },
            { nivel = 8, precio = 40, xp = 6 },
            { nivel = 9, precio = 45, xp = 2 },
            { nivel = 10, precio = 50, xp = 1 }
        },
        niveles = {
            { nivel = 1, siguienteNivel = 200 },
            { nivel = 2, siguienteNivel = 400 },
            { nivel = 3, siguienteNivel = 600 },
            { nivel = 4, siguienteNivel = 800 },
            { nivel = 5, siguienteNivel = 1000 },
            { nivel = 6, siguienteNivel = 1200 },
            { nivel = 7, siguienteNivel = 1400 },
            { nivel = 8, siguienteNivel = 1600 },
            { nivel = 9, siguienteNivel = 1800 },
            { nivel = 10, siguienteNivel = 2000 }
        }
    },
    coordenadas = {
        ["calle"] = {
            vector3(-1220.64, -1191.61, 7.69),
            vector3(-1175.23, -1325.13, 5.04),
            vector3(-1175.23, -1325.13, 5.04),
            vector3(-1112.15, -1445.44, 5.11),
            vector3(-1028.69, -1567.05, 5.14),
            vector3(-1031.37, -1328.62, 5.59),
            vector3(-802.59, -1335.88, 5.15),
            vector3(-256.95, -885.14, 30.85),
            vector3(-195.87, -666.68, 33.88),
            vector3(-488.16, -671.2, 32.83)
        },
        ["jardin"] = {
            vector3(-1128.21, 325.74, 67.5),
            vector3(-1005.75, 408.87, 73.23),
            vector3(-482.23, 585.57, 126.7),
            vector3(-310.2, 435.29, 109.08),
            vector3(-1682.1, -314.04, 51.71),
            vector3(-1761.16, -418.92, 43.56),
            vector3(-1821.26, -461.07, 43.25),
            vector3(-1966.27, -432.45, 17.94),
            vector3(-1433.65, -855.11, 16.24),
            vector3(-910.99, -787.99, 16.06)
        },
        ["ventana"] = {
            vector3(-1195.43, -1287.92, 6.41),
            vector3(-1103.45, -1287.17, 6.32),
            vector3(-888.88, -1229.89, 6.07),
            vector3(-1027.13, -1044.36, 2.56),
            vector3(-1218.86, -898.1, 13.0),
            vector3(-992.04, -756.28, 21.28),
            vector3(-1211.11, -579.4, 28.18),
            vector3(-1362.32, -354.83, 37.16),
            vector3(-1394.85, -231.77, 44.56),
            vector3(-929.44, -221.82, 39.07)
        }
    }
}

-- Textos en español
Config.Textos = {
    yaTrabajas = "Ya estas trabajando",
    siguiente = "Ve al siguiente punto. Te quedan %d puntos.",
    sinVehiculo = "Debes salir del vehiculo",
    finalizado = "Trabajo finalizado, vuelve a la empresa",
    vehiculoFinalizado = "Vehiculo devuelto correctamente",
    vehiculoIncorrecto = "Este no es tu vehiculo de trabajo",
    trabajoCancelado = "Trabajo cancelado"
}

-- CONFIGURACIÓN DE MODS PARA VEHÍCULOS DE TRABAJO
Config.VehicleMods = {
    ["pony"] = {
        primaryColor = 154,          -- color primario
        secondaryColor = 154,       -- color secundario
        rimColor = 131,             -- color de llanta
        wheelType = 10,             -- tipo de rueda
        wheelIndex = 10,            -- modelo de rueda
        livery = 0,                 -- diseño (si tiene)
        
        -- MODS (0 a 48)
        mods = {
            [0] = 0,
            [1] = 1,
            [2] = 4,
            [3] = 0,
            [4] = 4,
            [6] = 9,
            [7] = 8,
            [27] = 2,
            [35] = 0,
            [43] = 4,
            [44] = 3
        },

        -- EXTRAS (true = activar, false = desactivar)
        extras = {
            [1] = true,
            [2] = true,
            [3] = false,
            [4] = true,
            [5] = true,
            [6] = true,
            [7] = false,
            [8] = false,
            [9] = true
        }
    }
}


Config.RopaTrabajo = { 
    male = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 60, texture = 3 },
        ['torso2'] = { component = 11, drawable = 42, texture = 0 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 37, texture = 0 },
        ['pants'] = { component = 4, drawable = 102, texture = 3 },
        ['shoes'] = { component = 6, drawable = 14, texture = 0 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = 0, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    },
    female = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 129, texture = 2 },
        ['torso2'] = { component = 11, drawable = 245, texture = 7 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 44, texture = 0 },
        ['pants'] = { component = 4, drawable = 27, texture = 2 },
        ['shoes'] = { component = 6, drawable = 1, texture = 4 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = -1, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    }
}