-- client.lua (reemplaza tu antiguo client.lua con este)
local QBCore = exports['qb-core']:GetCoreObject()
local showText = false
local currentWorkText = "E - Realizar tarea"
local ropaCivil = nil

local TrabajoPlayer = {
    activo = false,
    vehiculoRemovido = false,
    trabajoSeleccionado = nil,
    trabajos = {},
    precio = nil,
    xp = nil,
    vehiculo = nil,
    objetoActual = nil,
    enProgreso = false,

    blipActual = nil,      -- único blip activo
    currentCoord = nil,    -- coord del punto actual
    currentIndex = nil,    -- índice dentro de la lista trabajos
    stage = 0              -- 0 = idle/seleccionar, 1 = esperando llegada, 2 = procesando animación
}

-- Función para notificaciones
local function Notificar(texto, tipo)
    QBCore.Functions.Notify(texto, tipo)
end

-- UI
local function AbrirInterfaz()
    if not TrabajoPlayer.activo then
        QBCore.Functions.TriggerCallback('sh-limpio:obtenerDatos', function(respuesta)
            local precioCalle = Config.Trabajos.ajustes["calle"][respuesta.nivel].precio
            local precioJardin = Config.Trabajos.ajustes["jardin"][respuesta.nivel].precio
            local precioVentana = Config.Trabajos.ajustes["ventana"][respuesta.nivel].precio
            local pasosCalle = #Config.Trabajos.coordenadas["calle"]
            local pasosJardin = #Config.Trabajos.coordenadas["jardin"]
            local pasosVentana = #Config.Trabajos.coordenadas["ventana"]
            
            SendNUIMessage({
                action = 'open',
                playerName = respuesta.nombre,
                level = respuesta.nivel,
                xp = respuesta.xp,
                sprice = precioCalle,
                gprice = precioJardin,
                wprice = precioVentana,
                streetStep = pasosCalle,
                gardenStep = pasosJardin,
                windowStep = pasosVentana
            })
            SetNuiFocus(true, true)
        end)
    else
        Notificar(Config.Textos.yaTrabajas, 'error')
    end
end

function GenerarPatenteLimpieza()
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local out = "CLE"
    for i = 1, 5 do
        local rand = math.random(1, #chars)
        out = out .. chars:sub(rand, rand)
    end
    return out
end

-- FUNCIÓN PARA TEXTO 2D CORRECTO
local function DrawText2D(x, y, text)
    SetTextFont(6)
    SetTextScale(0.40, 0.40)
    SetTextColour(0, 0, 0, 255)
    SetTextCentre(true)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x, y)
end

-- THREAD QUE DIBUJA EL RECTÁNGULO Y TEXTO
CreateThread(function()
    while true do
        if showText then
            -- fondo negro
            DrawRect(0.27, 0.65, 0.22, 0.035, 252, 107, 3, 165)
            -- texto centrado
            DrawText2D(0.27, 0.635, currentWorkText)
        else
            Wait(200)
        end
        Wait(0)
    end
end)

function PonerRopaTrabajo()
    local ped = PlayerPedId()

    -- Guardar ropa civil solo la primera vez
    if not ropaCivil then
        ropaCivil = {}

        -- Guardar componentes (0 a 11)
        for i = 0, 11 do
            ropaCivil[i] = {
                drawable = GetPedDrawableVariation(ped, i),
                texture = GetPedTextureVariation(ped, i)
            }
        end

        -- Guardar props (0 a 7 aprox)
        for i = 0, 7 do
            ropaCivil["prop"..i] = {
                drawable = GetPedPropIndex(ped, i),
                texture = GetPedPropTextureIndex(ped, i)
            }
        end
    end

    -- Detectar género del ped
    local esHombre = (GetEntityModel(ped) == GetHashKey("mp_m_freemode_01"))
    local genero = esHombre and "male" or "female"

    local ropa = Config.RopaTrabajo[genero]
    if not ropa then return end

    -- Aplicar ropa
    for _, v in pairs(ropa) do
        if v.component then
            SetPedComponentVariation(ped, v.component, v.drawable, v.texture, 0)
        elseif v.prop then
            ClearPedProp(ped, v.prop)
            if v.drawable ~= -1 then
                SetPedPropIndex(ped, v.prop, v.drawable, v.texture, true)
            end
        end
    end
end

function RestaurarRopaTrabajo()
    if not ropaCivil then return end

    local ped = PlayerPedId()

    -- Restaurar componentes
    for i = 0, 11 do
        local data = ropaCivil[i]
        if data then
            SetPedComponentVariation(ped, i, data.drawable, data.texture, 0)
        end
    end

    -- Restaurar props
    for i = 0, 7 do
        local data = ropaCivil["prop"..i]

        ClearPedProp(ped, i)

        if data and data.drawable ~= -1 then
            SetPedPropIndex(ped, i, data.drawable, data.texture, true)
        end
    end

    ropaCivil = nil -- listo para el próximo trabajo
end


RegisterNUICallback('selectJob', function(data, cb)
    QBCore.Functions.TriggerCallback('sh-limpio:obtenerDatos', function(respuesta)
        local trabajo = data.selected
        TrabajoPlayer.precio = Config.Trabajos.ajustes[trabajo][respuesta.nivel].precio
        TrabajoPlayer.xp = Config.Trabajos.ajustes[trabajo][respuesta.nivel].xp
        TrabajoPlayer.trabajoSeleccionado = trabajo

        -- LIMPIAR lista antes de poblarla
        TrabajoPlayer.trabajos = {}

        if trabajo == 'calle' then
            for _, v in ipairs(Config.Trabajos.coordenadas["calle"]) do
                table.insert(TrabajoPlayer.trabajos, v)
            end
            TrabajoCalle()
        elseif trabajo == 'jardin' then
            for _, v in ipairs(Config.Trabajos.coordenadas["jardin"]) do
                table.insert(TrabajoPlayer.trabajos, v)
            end
            TrabajoJardin()
                elseif trabajo == 'ventana' then
            for _, v in ipairs(Config.Trabajos.coordenadas["ventana"]) do
                table.insert(TrabajoPlayer.trabajos, v)
            end
             TrabajoVentana()
        end
    end)
    cb('ok')
end)

-- UTIL: Crear/actualizar blip único y activar ruta (waypoint amarilla)
function CrearBlipTrabajo(coord)
    if not coord then return end

    -- eliminar el blip anterior si existe (apagar ruta antes)
    if TrabajoPlayer.blipActual and DoesBlipExist(TrabajoPlayer.blipActual) then
        SetBlipRoute(TrabajoPlayer.blipActual, false)
        RemoveBlip(TrabajoPlayer.blipActual)
        TrabajoPlayer.blipActual = nil
    end

    local blip = AddBlipForCoord(coord.x, coord.y, coord.z)
    SetBlipSprite(blip, 478)
    SetBlipScale(blip, 0.6)
    SetBlipColour(blip, 5)          -- amarillo
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Tarea")
    EndTextCommandSetBlipName(blip)

    -- activar ruta (línea amarilla)
    SetBlipRoute(blip, true)
    if type(SetBlipRouteColour) == "function" then
        SetBlipRouteColour(blip, 5)
    end

    TrabajoPlayer.blipActual = blip
end

-- UTIL: Eliminar blip actual (apagar ruta primero)
local function EliminarBlipActual()
    if TrabajoPlayer.blipActual and DoesBlipExist(TrabajoPlayer.blipActual) then
        SetBlipRoute(TrabajoPlayer.blipActual, false)
        RemoveBlip(TrabajoPlayer.blipActual)
    end
    TrabajoPlayer.blipActual = nil
end

-- Animaciones (no tocan blip; el blip se eliminará desde el flujo principal al finalizar)
function CargarAnim(anim)
    RequestAnimDict(anim)
    while not HasAnimDictLoaded(anim) do
        Wait(100)
    end
end

function AnimacionLimpieza(entidad)
    RequestModel("prop_tool_broom")
    while not HasModelLoaded("prop_tool_broom") do
        Wait(10)
    end

    local player = PlayerPedId()
    local coords = GetEntityCoords(player)
    local objeto = CreateObject(GetHashKey("prop_tool_broom"), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(objeto, player, GetPedBoneIndex(player, 28422), 0.0, 0.0, 0.24, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    
    local animDict = 'anim@amb@drug_field_workers@rake@male_b@base'
    local animName = 'base'
    CargarAnim(animDict)
    TaskPlayAnim(player, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)
    
    local alphaLevel = 255
    while alphaLevel > 20 do
        Wait(500)
        alphaLevel = alphaLevel - 50
        if entidad and DoesEntityExist(entidad) then
            SetEntityAlpha(entidad, alphaLevel, 0)
        end
    end
    
    ClearPedTasksImmediately(player)
    DeleteObject(objeto)
end

function AnimacionJardin(entidad)
    RequestModel("w_me_hatchet")
    while not HasModelLoaded("w_me_hatchet") do
        Wait(10)
    end

    local player = PlayerPedId()
    local coords = GetEntityCoords(player)
    local hacha = CreateObject(GetHashKey("w_me_hatchet"), coords.x, coords.y, coords.z, true, true, true)
    AttachEntityToEntity(hacha, player, GetPedBoneIndex(player, 57005), 0.1, 0.0, 0.0, 0.0, 270.0, 90.0, true, true, false, true, 1, true)

    local animDict = "melee@hatchet@streamed_core"
    local animName = "plyr_rear_takedown_b"
    CargarAnim(animDict)
    TaskPlayAnim(player, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)

    local alphaLevel = 255
    while alphaLevel > 20 do
        Wait(500)
        alphaLevel = alphaLevel - 50
        if entidad and DoesEntityExist(entidad) then
            SetEntityAlpha(entidad, alphaLevel, 0)
        end
    end

    ClearPedTasksImmediately(player)
    DeleteObject(hacha)
end

function AnimacionVentana(objeto)
    local ped = PlayerPedId()
    local dict = "amb@world_human_maid_clean@idle_a"
    local anim = "idle_a"

    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) end

    -- Crear prop de esponja
    local prop = CreateObject(GetHashKey("prop_sponge_01"), 0, 0, 0, true, true, true)
    AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 28422), -0.07, 0.05, -0.03, 0.0, 105.5, 90.0, true, true, false, true, 1, true)

    TaskPlayAnim(ped, dict, anim, 4.0, -4.0, 5000, 49, 0, false, false, false)
    Wait(5000)

    ClearPedTasks(ped)
    DeleteObject(prop)
end


function EliminarVehiculoTrabajo()
    if not TrabajoPlayer.patenteVehiculo then return end

    local placaObjetivo = TrabajoPlayer.patenteVehiculo

    -- Revisar todos los vehículos del mundo
    local vehs = GetGamePool("CVehicle")

    for _, veh in ipairs(vehs) do
        if DoesEntityExist(veh) then
            local placa = GetVehicleNumberPlateText(veh)
            if placa == placaObjetivo then
                DeleteVehicle(veh)
            end
        end
    end

    -- Limpieza
    TrabajoPlayer.patenteVehiculo = nil
    TrabajoPlayer.vehiculoEntity = nil
end

-- DAR VEHICULO
function DarVehiculo()
    local modelo = Config.Empresa.vehiculoTrabajo
    local modsConf = Config.VehicleMods[modelo]

    RequestModel(modelo)
    while not HasModelLoaded(modelo) do
        Wait(0)
    end

    local coords = Config.Empresa.ubicacionVehiculo
    local vehiculo = CreateVehicle(GetHashKey(modelo), coords.x, coords.y, coords.z, coords.w, true, false)

    -- Matrícula
    local placa = GenerarPatenteLimpieza()
    SetVehicleNumberPlateText(vehiculo, placa)

    TriggerEvent("vehiclekeys:client:SetOwner", placa)
    TrabajoPlayer.patenteVehiculo = placa
    TrabajoPlayer.vehiculoEntity = vehiculo

    -- Aplicar COLORES
    if modsConf then
        SetVehicleColours(vehiculo, modsConf.primaryColor or 0, modsConf.secondaryColor or 0)
        SetVehicleExtraColours(vehiculo, modsConf.rimColor or 0, 0)

-- Mod kit obligatorio
SetVehicleModKit(vehiculo, 0)

-- Ruedas
if modsConf.wheelType ~= nil then
    SetVehicleWheelType(vehiculo, modsConf.wheelType)
    Wait(50) -- Muy importante
end

if modsConf.wheelIndex ~= nil then
    -- Aplicar al eje delantero
    SetVehicleMod(vehiculo, 23, modsConf.wheelIndex, false)
    -- Aplicar al eje trasero (si existe)
    SetVehicleMod(vehiculo, 24, modsConf.wheelIndex, false)

    -- Truco para forzar refresco
    Wait(50)
    SetVehicleMod(vehiculo, 23, modsConf.wheelIndex, false)
    SetVehicleMod(vehiculo, 24, modsConf.wheelIndex, false)
end


        -- Livery
        if modsConf.livery then
            SetVehicleLivery(vehiculo, modsConf.livery)
        end

        -- MODS (motor, frenos, defensas, etc.)
        if modsConf.mods then
            for modIndex, modValue in pairs(modsConf.mods) do
                SetVehicleMod(vehiculo, tonumber(modIndex), tonumber(modValue), false)
            end
        end

        -- EXTRAS del vehículo (barras, parachoques, etc.)
        if modsConf.extras then
            for extraId, enabled in pairs(modsConf.extras) do
                SetVehicleExtra(vehiculo, tonumber(extraId), enabled and 0 or 1)
            end
        end
    end

    -- Poner jugador dentro
    SetPedIntoVehicle(PlayerPedId(), vehiculo, -1)
end

local function SeleccionarSiguientePunto()
    if not TrabajoPlayer.trabajos or #TrabajoPlayer.trabajos == 0 then
        return nil, nil
    end
    local idx = math.random(1, #TrabajoPlayer.trabajos)
    local coord = TrabajoPlayer.trabajos[idx]
    return coord, idx
end

local function StartNextPoint()
    -- limpiar cualquier objeto viejo por seguridad
    if TrabajoPlayer.objetoActual and DoesEntityExist(TrabajoPlayer.objetoActual) then
        DeleteObject(TrabajoPlayer.objetoActual)
        TrabajoPlayer.objetoActual = nil
    end

    -- eliminar decal previo si existiera
    if TrabajoPlayer.decalCoord then
        RemoveDecalsInRange(
            TrabajoPlayer.decalCoord.x,
            TrabajoPlayer.decalCoord.y,
            TrabajoPlayer.decalCoord.z,
            1.5
        )
        TrabajoPlayer.decalCoord = nil
    end

    local coord, idx = SeleccionarSiguientePunto()
    if not coord then
        TrabajoPlayer.currentCoord = nil
        TrabajoPlayer.currentIndex = nil
        TrabajoPlayer.stage = 0
        return false
    end

    -- asignar current
    TrabajoPlayer.currentCoord = coord
    TrabajoPlayer.currentIndex = idx
    TrabajoPlayer.stage = 1 -- esperando llegada

-- VENTANA → USAR DECAL EN LUGAR DE PROP
if TrabajoPlayer.trabajoSeleccionado == "ventana" then
    
    local decZ = coord.z + 0.7

    local decalId = AddDecal(
        1020,                       -- splatters_mud
        coord.x, coord.y, decZ,     -- pos
        0.0, 0.0, -1.0,             -- dir
        0.0, 1.0, 0.0,              -- side vector
        0.0,                        -- sideZ (FALTABA ESTE)
        0.6,                        -- width
        0.6,                        -- height
        255,                        -- rCoef
        255,                        -- gCoef
        255,                        -- bCoef
        255,                        -- opacity
        120000,                     -- timeout
        false,                      -- isLongRange
        false,                      -- isDynamic
        false                       -- useComplexColn
    )

    TrabajoPlayer.decalCoord = vector3(coord.x, coord.y, decZ)
    TrabajoPlayer.objetoActual = nil


    -- guardar posición para borrarlo al completar
    TrabajoPlayer.decalCoord = vector3(coord.x, coord.y, decZ)

    TrabajoPlayer.objetoActual = nil
        
    else
    ---------------------------------------------------------------------
    -- CALLE + JARDIN (sin tocar nada tuyo)
    ---------------------------------------------------------------------
        local modelHash = GetHashKey(
            TrabajoPlayer.trabajoSeleccionado == "calle"
                and 'proc_litter_01'
                or 'prop_tree_olive_01'
        )

        RequestModel(modelHash)
        local t0 = GetGameTimer()
        while not HasModelLoaded(modelHash) and (GetGameTimer() - t0) < 5000 do
            Wait(5)
        end

        local zAdjust = (TrabajoPlayer.trabajoSeleccionado == "calle") and -1.0 or -2.5

        TrabajoPlayer.objetoActual = CreateObject(
            modelHash,
            coord.x, coord.y, coord.z + zAdjust,
            true, true, true
        )

        FreezeEntityPosition(TrabajoPlayer.objetoActual, true)
    end

    ---------------------------------------------------------------------
    -- CREAR BLIP HACIA EL PUNTO
    ---------------------------------------------------------------------
    CrearBlipTrabajo(TrabajoPlayer.currentCoord)
    return true
end


-- LIMPIAR ESTADO
function LimpiarTrabajoPlayer()
    -- eliminar objeto si existe
    if TrabajoPlayer.objetoActual and DoesEntityExist(TrabajoPlayer.objetoActual) then
        DeleteObject(TrabajoPlayer.objetoActual)
        TrabajoPlayer.objetoActual = nil
    end

    -- eliminar blip actual
    EliminarBlipActual()

    -- resetear tabla conservando local
    TrabajoPlayer.activo = false
    TrabajoPlayer.vehiculoRemovido = false
    TrabajoPlayer.trabajoSeleccionado = nil
    TrabajoPlayer.trabajos = {}
    TrabajoPlayer.precio = nil
    TrabajoPlayer.xp = nil
    TrabajoPlayer.vehiculo = nil
    TrabajoPlayer.objetoActual = nil
    TrabajoPlayer.enProgreso = false
    TrabajoPlayer.currentCoord = nil
    TrabajoPlayer.currentIndex = nil
    TrabajoPlayer.stage = 0
    TrabajoPlayer.blipActual = nil
end

-- VOLVER EMPRESA (DEVOLVER VEHICULO)
function VolverEmpresa()
    Notificar(Config.Textos.finalizado, 'success')

    -- crear blip amarillo para devolver vehículo
    local coordDevolver = Config.Empresa.devolverVehiculo
    local blip = AddBlipForCoord(coordDevolver.x, coordDevolver.y, coordDevolver.z)
    SetBlipSprite(blip, 1)           -- icono básico
    SetBlipColour(blip, 5)           -- amarillo
    SetBlipScale(blip, 0.9)
    SetBlipRoute(blip, true)         -- ruta amarilla
    SetBlipRouteColour(blip, 5)

    -- guardar el blip por si querés eliminarlo después de entregar
    TrabajoPlayer.blipActual = blip

    TrabajoPlayer.vehiculoRemovido = true


    while TrabajoPlayer.vehiculoRemovido do
        Wait(0)

        local player = PlayerPedId()
        local vehiculo = GetVehiclePedIsIn(player, false)
        local distancia = #(GetEntityCoords(player) - coordDevolver)

        -- eliminar escoba si existe
        if TrabajoPlayer.objetoActual and DoesEntityExist(TrabajoPlayer.objetoActual) then
            DeleteObject(TrabajoPlayer.objetoActual)
            TrabajoPlayer.objetoActual = nil
        end

        -- marcador en el suelo
        if distancia < 20 then
            DrawMarker(
                2, coordDevolver.x, coordDevolver.y, coordDevolver.z,
                0.0, 0.0, 0.0,
                180.0, 0.0, 0.0,
                0.65, 0.65, 0.65,
                252, 107, 3, 100,
                false, true, 2, false, false, false, false
            )

            if distancia < 3 then
                if IsControlJustReleased(0, 38) then
                    local vehiculoModelo = GetEntityModel(vehiculo)
                    local modeloCorrecto = GetHashKey(Config.Empresa.vehiculoTrabajo)

                    -- eliminar el blip de devolución
                    if TrabajoPlayer.blipActual then
                        SetBlipRoute(TrabajoPlayer.blipActual, false)
                        RemoveBlip(TrabajoPlayer.blipActual)
                        TrabajoPlayer.blipActual = nil
                    end

if vehiculoModelo == modeloCorrecto then
    EliminarVehiculoTrabajo()   -- SIEMPRE ELIMINA EL VEHÍCULO DEL TRABAJO
    Notificar(Config.Textos.vehiculoFinalizado, "success")

    RestaurarRopaTrabajo()

else
    Notificar(Config.Textos.vehiculoIncorrecto, "error")
end


                    TrabajoPlayer.vehiculoRemovido = false
                    LimpiarTrabajoPlayer()
                    break
                end
            end
        end
    end
end


-- TRABAJO CALLE (nuevo flujo por etapas)
function TrabajoCalle()
    local precioXp = { money = TrabajoPlayer.precio, xp = TrabajoPlayer.xp }

     PonerRopaTrabajo()

    DarVehiculo()
    TrabajoPlayer.activo = true
    TrabajoPlayer.stage = 0

    -- primero: preparar modelo de basura
    local hash = GetHashKey('proc_litter_01')
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(0)
    end

    -- iniciar con primer punto
    if not StartNextPoint() then
        -- sin puntos => salir
        TrabajoPlayer.activo = false
        return
    end

    -- bucle principal: maneja etapas
    while TrabajoPlayer.activo do
        local sleep = 1000
        if TrabajoPlayer.stage == 1 and TrabajoPlayer.currentCoord then
            sleep = 0
            local playerCoords = GetEntityCoords(PlayerPedId())
            local distancia = #(playerCoords - TrabajoPlayer.currentCoord)

            -- dibujar marker local (sigue mostrando el marker verde en mundo)
            if distancia < 50 then
                DrawMarker(2, TrabajoPlayer.currentCoord.x, TrabajoPlayer.currentCoord.y, TrabajoPlayer.currentCoord.z, 0.0, 0.0, 0.0,
                    180.0, 0.0, 0.0, 0.65, 0.65, 0.65, 252, 107, 3, 100, false, true, 2, false, false, false, false)
            end

            if distancia < 2 and TrabajoPlayer.objetoActual then
                if IsControlJustReleased(0, 38) then
                    if TrabajoPlayer.enProgreso then
                        -- evitar re-entradas
                    else
                        if not IsPedInAnyVehicle(PlayerPedId(), false) then
                            TrabajoPlayer.enProgreso = true
                            -- pasar a etapa 2: ejecutar animación
                            TrabajoPlayer.stage = 2

                            -- girar ped hacia objeto y ejecutar animación (bloqueante dentro del hilo)
                            TaskTurnPedToFaceEntity(PlayerPedId(), TrabajoPlayer.objetoActual, -1)

                            -- elegir animación según trabajo
                            AnimacionLimpieza(TrabajoPlayer.objetoActual)

                            -- al finalizar animación: eliminar prop y blip, dar recompensa, y planear siguiente
                            if TrabajoPlayer.objetoActual and DoesEntityExist(TrabajoPlayer.objetoActual) then
                                DeleteObject(TrabajoPlayer.objetoActual)
                                TrabajoPlayer.objetoActual = nil
                            end

                            -- eliminar blip actual (apagar ruta primero)
                            EliminarBlipActual()

                            -- remover el punto completado de la lista para no repetirlo
                            if TrabajoPlayer.currentIndex then
                                table.remove(TrabajoPlayer.trabajos, TrabajoPlayer.currentIndex)
                            end

                            -- pago y xp (asincrono)
                            QBCore.Functions.TriggerCallback('sh-limpio:agregarXpDinero', function(data)
                                if data == 'subioNivel' then
                                    SendNUIMessage({ action = 'levelUp' })
                                end
                            end, precioXp)

                            -- decidir siguiente acción
                            if #TrabajoPlayer.trabajos == 0 then
                                -- ya no quedan puntos: terminar trabajo y volver a empresa
                                TrabajoPlayer.enProgreso = false
                                TrabajoPlayer.activo = false
                                CreateThread(function() VolverEmpresa() end)
                                break
                            else
                                -- iniciar siguiente punto (reutiliza StartNextPoint)
local restantes = #TrabajoPlayer.trabajos
local mensaje = string.format(Config.Textos.siguiente, restantes)

StartNextPoint()
Notificar(mensaje, 'success')
TrabajoPlayer.enProgreso = false
TrabajoPlayer.stage = 1

                            end
                        else
                            Notificar(Config.Textos.sinVehiculo, 'error')
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end

-- TRABAJO JARDIN (misma lógica que Calle, con modelos/anim ajuste)
function TrabajoJardin()
    local precioXp = { money = TrabajoPlayer.precio, xp = TrabajoPlayer.xp }

     PonerRopaTrabajo()

    DarVehiculo()
    TrabajoPlayer.activo = true
    TrabajoPlayer.stage = 0

    local hash = GetHashKey('prop_tree_olive_01')
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(0)
    end

    if not StartNextPoint() then
        TrabajoPlayer.activo = false
        return
    end

    while TrabajoPlayer.activo do
        local sleep = 1000
        if TrabajoPlayer.stage == 1 and TrabajoPlayer.currentCoord then
            sleep = 0
            local playerCoords = GetEntityCoords(PlayerPedId())
            local distancia = #(playerCoords - TrabajoPlayer.currentCoord)

            if distancia < 50 then
                DrawMarker(2, TrabajoPlayer.currentCoord.x, TrabajoPlayer.currentCoord.y, TrabajoPlayer.currentCoord.z, 0.0, 0.0, 0.0,
                    180.0, 0.0, 0.0, 0.65, 0.65, 0.65, 252, 107, 3, 100, false, true, 2, false, false, false, false)
            end

            if distancia < 2 and TrabajoPlayer.objetoActual then
                if IsControlJustReleased(0, 38) then
                    if TrabajoPlayer.enProgreso then
                    else
                        if not IsPedInAnyVehicle(PlayerPedId(), false) then
                            TrabajoPlayer.enProgreso = true
                            TrabajoPlayer.stage = 2

                            TaskTurnPedToFaceEntity(PlayerPedId(), TrabajoPlayer.objetoActual, -1)
                            AnimacionJardin(TrabajoPlayer.objetoActual)

                            if TrabajoPlayer.objetoActual and DoesEntityExist(TrabajoPlayer.objetoActual) then
                                DeleteObject(TrabajoPlayer.objetoActual)
                                TrabajoPlayer.objetoActual = nil
                            end

                            EliminarBlipActual()

                            if TrabajoPlayer.currentIndex then
                                table.remove(TrabajoPlayer.trabajos, TrabajoPlayer.currentIndex)
                            end

                            QBCore.Functions.TriggerCallback('sh-limpio:agregarXpDinero', function(data)
                                if data == 'subioNivel' then
                                    SendNUIMessage({ action = 'levelUp' })
                                end
                            end, precioXp)

                            if #TrabajoPlayer.trabajos == 0 then
                                TrabajoPlayer.enProgreso = false
                                TrabajoPlayer.activo = false
                                CreateThread(function() VolverEmpresa() end)
                                break
                            else
local restantes = #TrabajoPlayer.trabajos
local mensaje = string.format(Config.Textos.siguiente, restantes)

StartNextPoint()
Notificar(mensaje, 'success')
TrabajoPlayer.enProgreso = false
TrabajoPlayer.stage = 1

                            end
                        else
                            Notificar(Config.Textos.sinVehiculo, 'error')
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end

function TrabajoVentana()
    local precioXp = { money = TrabajoPlayer.precio, xp = TrabajoPlayer.xp }

    DarVehiculo()
    PonerRopaTrabajo()

    TrabajoPlayer.activo = true
    TrabajoPlayer.stage = 0

    -- NO cargamos ningún modelo porque ya no usamos props

    if not StartNextPoint() then
        TrabajoPlayer.activo = false
        return
    end

    while TrabajoPlayer.activo do
        local sleep = 1000

        if TrabajoPlayer.stage == 1 and TrabajoPlayer.currentCoord then
            sleep = 0

            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local distancia = #(coords - TrabajoPlayer.currentCoord)

            -- marker visual
            if distancia < 50 then
                DrawMarker(2,
                    TrabajoPlayer.currentCoord.x,
                    TrabajoPlayer.currentCoord.y,
                    TrabajoPlayer.currentCoord.z + 0.3,
                    0.0, 0.0, 0.0,
                    180.0, 0.0, 0.0,
                    0.55, 0.55, 0.55,
                    252, 107, 3, 100,
                    false, true, 2, false, false, false, false
                )
            end

            -- YA NO usamos objetoActual, el decal actúa como punto a limpiar
            if distancia < 2 then
                if IsControlJustReleased(0, 38) then
                    if not TrabajoPlayer.enProgreso then
                        if not IsPedInAnyVehicle(ped, false) then

                            TrabajoPlayer.enProgreso = true
                            TrabajoPlayer.stage = 2

                            -- Gira hacia la ventana
                            TaskTurnPedToFaceCoord(
                                ped,
                                TrabajoPlayer.currentCoord.x,
                                TrabajoPlayer.currentCoord.y,
                                TrabajoPlayer.currentCoord.z + 1.2,
                                -1
                            )

                            -- animación con esponja
                            AnimacionVentana()

                            ------------------------------------------------------------------
                            -- BORRAR DECAL DE ESTA VENTANA
                            ------------------------------------------------------------------
                            if TrabajoPlayer.decalCoord then
                                RemoveDecalsInRange(
                                    TrabajoPlayer.decalCoord.x,
                                    TrabajoPlayer.decalCoord.y,
                                    TrabajoPlayer.decalCoord.z,
                                    1.5
                                )
                                TrabajoPlayer.decalCoord = nil
                            end

                            EliminarBlipActual()

                            if TrabajoPlayer.currentIndex then
                                table.remove(TrabajoPlayer.trabajos, TrabajoPlayer.currentIndex)
                            end

                            -- pago / xp
                            QBCore.Functions.TriggerCallback(
                                'sh-limpio:agregarXpDinero',
                                function(data)
                                    if data == 'subioNivel' then
                                        SendNUIMessage({ action = 'levelUp' })
                                    end
                                end,
                                precioXp
                            )

                            -- siguiente punto
                            if #TrabajoPlayer.trabajos == 0 then
                                TrabajoPlayer.enProgreso = false
                                TrabajoPlayer.activo = false
                                CreateThread(function() VolverEmpresa() end)
                                break
                            else
                                local restantes = #TrabajoPlayer.trabajos
                                local mensaje = string.format(Config.Textos.siguiente, restantes)

                                StartNextPoint()
                                Notificar(mensaje, 'success')
                                TrabajoPlayer.enProgreso = false
                                TrabajoPlayer.stage = 1
                            end

                        else
                            Notificar(Config.Textos.sinVehiculo, "error")
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end


-- Comando cancelar
RegisterCommand(Config.ComandoCancelar, function()
    local vehiculo = GetVehiclePedIsIn(PlayerPedId(), false)
    if TrabajoPlayer.activo then
        LimpiarTrabajoPlayer()
        if vehiculo ~= 0 then
            DeleteVehicle(vehiculo)
        end
        if TrabajoPlayer.objetoActual then
            DeleteObject(TrabajoPlayer.objetoActual)
        end
        Notificar(Config.Textos.trabajoCancelado, 'error')
    end  
end)

RegisterNUICallback('close', function(data, cb) 
    SetNuiFocus(false, false)
    cb('ok')
end)

-- NPC y blip de empresa
CreateThread(function()
    local modelo = GetHashKey(Config.Empresa.ped)
    RequestModel(modelo)
    while not HasModelLoaded(modelo) do
        Wait(0)
    end
    
    local ped = CreatePed(4, modelo, Config.Empresa.ubicacion.xyz, Config.Empresa.ubicacion.w, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    -------------------------------------------------------------
    -- SISTEMA DE TARGET AUTOMÁTICO
    -------------------------------------------------------------
    if Config.UsarTarget then
        ------------------------------------------------------------------
        -- OX_TARGET
        ------------------------------------------------------------------
        if exports.ox_target then
            exports.ox_target:addLocalEntity(ped, {
                {
                    name = 'limpieza_start',
                    label = 'Jefe de Limpieza',
                    icon = 'fa-solid fa-briefcase',
                    distance = 2.0,
                    onSelect = function()
                        AbrirInterfaz()
                    end
                },
                {
                    name = 'limpieza_finish',
                    label = 'Finalizar Trabajo',
                    icon = 'fa-solid fa-times-circle',
                    distance = 2.0,
                    onSelect = function()
                        if TrabajoPlayer.activo then

                            EliminarVehiculoTrabajo()
                            RestaurarRopaTrabajo()

                            if TrabajoPlayer.objetoActual then
                                DeleteObject(TrabajoPlayer.objetoActual)
                                TrabajoPlayer.objetoActual = nil
                            end

                            LimpiarTrabajoPlayer()
                            QBCore.Functions.Notify(Config.Textos.trabajoCancelado, 'error')
                        else
                            QBCore.Functions.Notify("Primero debes iniciar el trabajo", "error")
                        end
                    end
                }
            })
        end

    else
        ------------------------------------------------------------------
        -- QB_TARGET
        ------------------------------------------------------------------
        exports['qb-target']:AddTargetEntity(ped, {
            options = {
                {
                    label = 'Jefe de Limpieza',
                    icon = "fas fa-briefcase",
                    action = function()
                        AbrirInterfaz()
                    end
                },
                {
                    label = 'Finalizar Trabajo',
                    icon = "fas fa-times-circle",
                    action = function()
                        if TrabajoPlayer.activo then

                            EliminarVehiculoTrabajo()
                            RestaurarRopaTrabajo()

                            if TrabajoPlayer.objetoActual then
                                DeleteObject(TrabajoPlayer.objetoActual)
                                TrabajoPlayer.objetoActual = nil
                            end

                            LimpiarTrabajoPlayer()
                            QBCore.Functions.Notify(Config.Textos.trabajoCancelado, 'error')
                        else
                            QBCore.Functions.Notify("Primero debes iniciar el trabajo", "error")
                        end
                    end
                }
            },
            distance = 2.0
        })
    end
    -------------------------------------------------------------

    -- BLIP DE LA EMPRESA
    local blip = AddBlipForCoord(Config.Empresa.ubicacion.xyz)
    SetBlipSprite(blip, Config.Empresa.spriteBlip)
    SetBlipColour(blip, Config.Empresa.colorBlip)
    SetBlipScale(blip, Config.Empresa.tamanoBlip)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Empresa.nombre)
    EndTextCommandSetBlipName(blip)
end)

-- TEXTO SOLO PARA PUNTOS DE TRABAJO (NO EN DEVOLVER VEHÍCULO)
CreateThread(function()
    local puntoDevolver = Config.Empresa.devolverVehiculo

    while true do
        local sleep = 1000

        if TrabajoPlayer.activo and TrabajoPlayer.stage == 1 and TrabajoPlayer.currentCoord then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local dist = #(coords - TrabajoPlayer.currentCoord)

            if dist < 2 then
                local distDev = #(coords - puntoDevolver)

                -- evitar texto en punto de devolver la camioneta
                if distDev > 3.0 then
                    showText = true
                    currentWorkText = "E - Realizar Tareas de Mantenimiento"
                else
                    showText = false
                end
            else
                showText = false
            end
        else
            showText = false
        end

        Wait(sleep)
    end
end)