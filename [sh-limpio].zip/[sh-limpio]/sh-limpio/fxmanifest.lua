fx_version 'cerulean'
game 'gta5'
author 'SherlockCo'
lua54 'yes'

shared_script 'config.lua'

client_script 'client/client.lua'
server_script '@oxmysql/lib/MySQL.lua'
server_script 'server/server.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

dependencies {
    'oxmysql'
}
